
package com.sanad.app.feature.community;
import android.os.Bundle; import android.view.*; import android.widget.EditText; import android.widget.ImageButton; import android.widget.TextView;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager; import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R; import java.util.*;
public class CommunityFeedFragment extends Fragment {
  private CommunityViewModels.CommunityFeedVM vm; private RecyclerView rv; private EditText et; private ImageButton send;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){ return inflater.inflate(R.layout.fragment_community_feed, container, false); }
  @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s){
    super.onViewCreated(v,s);
    int id = getArguments()!=null? getArguments().getInt("communityId",-1): -1;
    String title = getArguments()!=null? getArguments().getString("communityTitle",""): "";
    requireActivity().setTitle(title);
    rv = v.findViewById(R.id.rvFeed); et = v.findViewById(R.id.etPost); send = v.findViewById(R.id.btnSend);
    rv.setLayoutManager(new LinearLayoutManager(requireContext()));
    Adapter ad = new Adapter(); rv.setAdapter(ad);
    vm = new ViewModelProvider(this).get(CommunityViewModels.CommunityFeedVM.class);
    vm.feed.observe(getViewLifecycleOwner(), ad::submit);
    if(id>0) vm.open(id);
    send.setOnClickListener(x -> { String t = et.getText().toString().trim(); if(!t.isEmpty()){ vm.post(t); et.setText(""); }});
  }
  static class Adapter extends RecyclerView.Adapter<Adapter.VH> {
    private final List<CommunityModels.Post> data = new ArrayList<>();
    void submit(List<CommunityModels.Post> d){ data.clear(); if(d!=null) data.addAll(d); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_post, p, false)); }
    @Override public void onBindViewHolder(@NonNull VH h, int i){
      CommunityModels.Post p = data.get(i);
      h.author.setText(p.author!=null? p.author.name : "—");
      h.body.setText(p.body!=null? p.body : "");
      h.meta.setText(p.created_at!=null? p.created_at : "");
    }
    @Override public int getItemCount(){ return data.size(); }
    static class VH extends RecyclerView.ViewHolder { TextView author, body, meta; VH(@NonNull View v){ super(v); author=v.findViewById(R.id.tvAuthor); body=v.findViewById(R.id.tvBody); meta=v.findViewById(R.id.tvMeta); } }
  }
}
