package com.sanad.app.data;

import java.util.List;
import java.util.Map;

public class LibraryModels {
    public static class Category {
        public int id;
        public Map<String,String> title; // {ar,en,tr}
        public List<ArticleListItem> articles;
    }
    public static class ArticleListItem {
        public int id;
        public Map<String,String> title; // {ar,en,tr}
        public String image;
        public String type;
        public String duration;
        public int category_id; // optional on index
    }
    public static class ArticleDetail {
        public int id;
        public Map<String,String> title;
        public Map<String,String> body;
        public String image;
        public String type;
        public String duration;
        public int category_id;
    }
}
