
package com.sanad.app.feature.specialist;
import android.os.Bundle; import android.view.*; import android.widget.TextView; import android.widget.Button;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;
public class SpecialistHomeFragment extends Fragment {
  private SpecialistViewModels.HomeVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_specialist_home, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    TextView tvUpcoming=v.findViewById(R.id.tvUpcoming), tvToday=v.findViewById(R.id.tvToday), tvPending=v.findViewById(R.id.tvPending);
    Button btnSessions=v.findViewById(R.id.btnSessions), btnProfile=v.findViewById(R.id.btnProfile);
    vm = new ViewModelProvider(this).get(SpecialistViewModels.HomeVM.class);
    vm.state.observe(getViewLifecycleOwner(), d->{ if(d!=null&&d.counters!=null){ tvUpcoming.setText(String.valueOf(d.counters.upcoming)); tvToday.setText(String.valueOf(d.counters.today)); tvPending.setText(String.valueOf(d.counters.pending)); } });
    btnSessions.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.specialistSessionsFragment));
    btnProfile.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.specialistProfileFragment));
    vm.load();
  }
}
