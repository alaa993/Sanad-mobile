
package com.sanad.app.feature.specialist;
import android.os.Bundle; import android.view.*; import android.widget.*;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;
public class SpecialistProfileFragment extends Fragment {
  private SpecialistViewModels.ProfileVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_specialist_profile, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    EditText etSpec=v.findViewById(R.id.etSpecialty), etYears=v.findViewById(R.id.etYears), etRate=v.findViewById(R.id.etRate), etCurrency=v.findViewById(R.id.etCurrency);
    Switch sw=v.findViewById(R.id.swAccepting);
    Button btn=v.findViewById(R.id.btnSave);
    vm=new ViewModelProvider(this).get(SpecialistViewModels.ProfileVM.class);
    vm.state.observe(getViewLifecycleOwner(), p->{ if(p!=null){ etSpec.setText(p.specialty==null?"":p.specialty); etYears.setText(String.valueOf(p.years_exp)); etRate.setText(String.valueOf(p.rate_cents)); etCurrency.setText(p.currency); sw.setChecked(p.accepting_new);} });
    btn.setOnClickListener(x->{ java.util.Map<String,Object> b=new java.util.HashMap<>(); b.put("specialty",etSpec.getText().toString().trim()); b.put("years_exp", Integer.parseInt(etYears.getText().toString().trim())); b.put("rate_cents", Integer.parseInt(etRate.getText().toString().trim())); b.put("currency", etCurrency.getText().toString().trim()); b.put("accepting_new", sw.isChecked()); vm.update(b); });
    vm.load();
  }
}
