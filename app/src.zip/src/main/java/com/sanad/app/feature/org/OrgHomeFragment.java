
package com.sanad.app.feature.org;
import android.os.Bundle; import android.view.*; import android.widget.TextView; import android.widget.Button;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;
public class OrgHomeFragment extends Fragment {
  private OrgViewModels.HomeVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_org_home, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    TextView tvUpcoming=v.findViewById(R.id.tvUpcoming), tvPending=v.findViewById(R.id.tvPending);
    Button btnSpecs=v.findViewById(R.id.btnSpecs), btnSessions=v.findViewById(R.id.btnSessions);
    vm=new ViewModelProvider(this).get(OrgViewModels.HomeVM.class);
    vm.state.observe(getViewLifecycleOwner(), d->{ if(d!=null&&d.counters!=null){ tvUpcoming.setText(String.valueOf(d.counters.upcoming)); tvPending.setText(String.valueOf(d.counters.pending)); } });
    btnSpecs.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.orgSpecialistsFragment));
    btnSessions.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.orgSessionsFragment));
    vm.load();
  }
}
