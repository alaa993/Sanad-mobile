
package com.sanad.app.feature.reports;
import android.os.Bundle; import android.view.*; import android.widget.*; import androidx.annotation.*; import androidx.fragment.app.Fragment;
import com.sanad.app.R;
public class ReportsFragment extends Fragment {
  private ReportsRepository repo; private TextView tvUsers,tvSessions,tvPaid,tvRevenue,tvRating; private EditText etFrom, etTo;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s)
  { return i.inflate(R.layout.fragment_reports, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    tvUsers=v.findViewById(R.id.tvUsers); tvSessions=v.findViewById(R.id.tvSessions); tvPaid=v.findViewById(R.id.tvPaid); tvRevenue=v.findViewById(R.id.tvRevenue); tvRating=v.findViewById(R.id.tvRating);
    etFrom=v.findViewById(R.id.etFrom); etTo=v.findViewById(R.id.etTo);
    repo=new ReportsRepository(requireContext());
    v.findViewById(R.id.btnRefresh).setOnClickListener(x -> load());
    load();
  }
  private void load(){
    String from = etFrom.getText()==null? "" : etFrom.getText().toString();
    String to   = etTo.getText()==null? "" : etTo.getText().toString();
    repo.overview(from,to,new ReportsRepository.Cb<ReportsApi.OverviewResponse>(){
      public void ok(ReportsApi.OverviewResponse d){
        tvUsers.setText("0"); tvSessions.setText("0"); tvPaid.setText("0"); tvRevenue.setText("0"); tvRating.setText("—");
        if(d.cards!=null) for(ReportsApi.OverviewResponse.Card c: d.cards){
          if(c==null||c.key==null) continue;
          switch(c.key){
            case "new_users": tvUsers.setText(String.valueOf(c.value)); break;
            case "sessions_total": tvSessions.setText(String.valueOf(c.value)); break;
            case "sessions_paid": tvPaid.setText(String.valueOf(c.value)); break;
            case "revenue": tvRevenue.setText(String.valueOf(c.value)); break;
            case "avg_rating": tvRating.setText(c.value==null? "—": String.valueOf(c.value)); break;
          }
        }
      }
      public void err(Throwable e){}
    });
  }
}
