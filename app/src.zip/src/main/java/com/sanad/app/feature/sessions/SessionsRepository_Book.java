package com.sanad.app.feature.sessions;

import android.content.Context;
import androidx.annotation.NonNull;
import com.sanad.app.data.AppConfig;
import com.sanad.app.data.auth.AuthInterceptor;
import okhttp3.OkHttpClient;
import retrofit2.*;

import retrofit2.converter.gson.GsonConverterFactory;

public class SessionsRepository_Book {
    private final SessionsApi api;
    public SessionsRepository_Book(Context ctx){
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppConfig.BASE_URL)
                .client(new OkHttpClient.Builder().addInterceptor(new AuthInterceptor(ctx)).build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        api = retrofit.create(SessionsApi.class);
    }
    public interface BookListener { void onSuccess(SessionModels.Session d); void onError(Throwable t); }
    public void book(BookRequest req, BookListener l){
        api.book(req).enqueue(new Callback<SessionModels.Session>() {
            @Override public void onResponse(@NonNull Call<SessionModels.Session> c, @NonNull Response<SessionModels.Session> r){
                if(!r.isSuccessful() || r.body()==null){ l.onError(new RuntimeException("bad_response")); return; }
                l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<SessionModels.Session> c, @NonNull Throwable t){ l.onError(t); }
        });
    }
}
