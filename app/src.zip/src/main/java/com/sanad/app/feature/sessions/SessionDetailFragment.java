package com.sanad.app.feature.sessions;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;

public class SessionDetailFragment extends Fragment {
    private SessionDetailViewModel vm;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_session_detail, container, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        int id = getArguments()!=null ? getArguments().getInt("sessionId", -1) : -1;

        TextView tvTitle = v.findViewById(R.id.tvTitle);
        TextView tvBody  = v.findViewById(R.id.tvBody);

        vm = new ViewModelProvider(this).get(SessionDetailViewModel.class);
        vm.getState().observe(getViewLifecycleOwner(), st -> {
            if (st==null || st.loading) return;
            if (st.error!=null){ tvTitle.setText("خطأ"); tvBody.setText(st.error); return; }
            SessionModels.Session d = st.data;
            tvTitle.setText(d.type + " · " + d.status);
            String spec = d.specialist!=null ? d.specialist.name : "-";
            String org  = d.organization!=null ? d.organization.name : "-";
            tvBody.setText("الموعد: " + d.scheduled_at + "\nالأخصائي: " + spec + "\nالمؤسسة: " + org + "\nملاحظات: " + (d.notes!=null?d.notes:"-"));
        });
        if (id>0) vm.load(id);
    }
}
