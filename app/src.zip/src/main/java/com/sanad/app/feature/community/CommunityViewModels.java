
package com.sanad.app.feature.community;
import android.app.Application; import androidx.annotation.NonNull; import androidx.lifecycle.*; import java.util.*;
public class CommunityViewModels {
  public static class CommunityListVM extends AndroidViewModel {
    private final CommunityRepository repo; public final MutableLiveData<List<CommunityModels.Community>> list = new MutableLiveData<>(new ArrayList<>());
    public CommunityListVM(@NonNull Application app){ super(app); repo = new CommunityRepository(app); }
    public void load(){ repo.communities(new CommunityRepository.Cb<CommunityModels.ListResponse<CommunityModels.Community>>(){
      @Override public void ok(CommunityModels.ListResponse<CommunityModels.Community> t){ list.postValue(t.data); }
      @Override public void err(Throwable e){} }); }
  }
  public static class CommunityFeedVM extends AndroidViewModel {
    private final CommunityRepository repo; public final MutableLiveData<List<CommunityModels.Post>> feed = new MutableLiveData<>(new ArrayList<>()); private int id=-1;
    public CommunityFeedVM(@NonNull Application app){ super(app); repo = new CommunityRepository(app); }
    public void open(int id){ this.id=id; load(); }
    public void load(){ if(id<=0) return; repo.feed(id, new CommunityRepository.Cb<CommunityModels.ListResponse<CommunityModels.Post>>(){ @Override public void ok(CommunityModels.ListResponse<CommunityModels.Post> t){ feed.postValue(t.data); } @Override public void err(Throwable e){} }); }
    public void post(String text){ if(id<=0) return; repo.post(id, text, new CommunityRepository.Cb<CommunityModels.SimpleResponse>(){ @Override public void ok(CommunityModels.SimpleResponse t){ load(); } @Override public void err(Throwable e){} }); }
  }
}
