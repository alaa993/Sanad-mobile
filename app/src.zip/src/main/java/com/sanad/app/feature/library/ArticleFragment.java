package com.sanad.app.feature.library;

import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;

public class ArticleFragment extends Fragment {
    private ArticleViewModel vm;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_article, container, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        int id = getArguments()!=null ? getArguments().getInt("articleId", -1) : -1;

        TextView tvTitle = v.findViewById(R.id.tvTitle);
        TextView tvBody  = v.findViewById(R.id.tvBody);

        vm = new ViewModelProvider(this).get(ArticleViewModel.class);
        vm.getState().observe(getViewLifecycleOwner(), st -> {
            if (st==null || st.loading) return;
            if (st.error!=null){ tvTitle.setText("Error"); tvBody.setText(st.error); return; }
            tvTitle.setText(st.article.title!=null && st.article.title.get("ar")!=null ? st.article.title.get("ar") : "");
            tvBody.setText(st.article.body!=null && st.article.body.get("ar")!=null ? st.article.body.get("ar") : "");
        });
        if (id>0) vm.load(id);
    }
}
