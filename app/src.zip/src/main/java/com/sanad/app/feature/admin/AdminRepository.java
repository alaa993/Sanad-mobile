
package com.sanad.app.feature.admin;
import android.content.Context; import com.sanad.app.data.ApiClient; import retrofit2.*;
public class AdminRepository {
  private final AdminApi api; public AdminRepository(Context ctx){ api=ApiClient.get(ctx).create(AdminApi.class); }
  public interface Cb<T>{ void ok(T t); void err(Throwable e); }
  private static <T> Callback<T> wrap(Cb<T> cb){ return new Callback<T>(){ public void onResponse(Call<T> c, retrofit2.Response<T> r){ if(r.isSuccessful()&&r.body()!=null) cb.ok(r.body()); else cb.err(new Exception("HTTP "+r.code())); } public void onFailure(Call<T> c, Throwable t){ cb.err(t);} }; }
  public void dashboard(Cb<AdminModels.Dashboard> cb){ api.dashboard().enqueue(wrap(cb)); }
  public void users(Cb<AdminModels.Users> cb){ api.users().enqueue(wrap(cb)); }
  public void specialists(Cb<AdminModels.Specialists> cb){ api.specialists().enqueue(wrap(cb)); }
  public void orgs(Cb<AdminModels.Organizations> cb){ api.orgs().enqueue(wrap(cb)); }
  public void appointments(Cb<AdminModels.Appointments> cb){ api.appointments().enqueue(wrap(cb)); }
  public void posts(Cb<AdminModels.Posts> cb){ api.posts().enqueue(wrap(cb)); }
  public void toggle(int id, Cb<AdminModels.Toggle> cb){ api.toggle(id).enqueue(wrap(cb)); }
  public void approveSpec(int id, Cb<AdminModels.Toggle> cb){ api.approveSpec(id).enqueue(wrap(cb)); }
  public void rejectSpec(int id, Cb<AdminModels.Toggle> cb){ api.rejectSpec(id).enqueue(wrap(cb)); }
  public void approveOrg(int id, Cb<AdminModels.Toggle> cb){ api.approveOrg(id).enqueue(wrap(cb)); }
  public void rejectOrg(int id, Cb<AdminModels.Toggle> cb){ api.rejectOrg(id).enqueue(wrap(cb)); }
}
