package com.sanad.app.feature.library;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.sanad.app.R;
import com.sanad.app.data.LibraryModels;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class LibraryFragment extends Fragment {

    private LibraryViewModel vm;
    private View progress, error, content;
    private RecyclerView rv;
    private CategoriesAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_library, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);

        // Views
        progress = v.findViewById(R.id.progress);
        error = v.findViewById(R.id.errorContainer);
        content = v.findViewById(R.id.content);
        rv = v.findViewById(R.id.rvArticles);

        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        adapter = new CategoriesAdapter();
        rv.setAdapter(adapter);

        // ViewModel
        vm = new ViewModelProvider(this).get(LibraryViewModel.class);

        // Observe state
        vm.getState().observe(getViewLifecycleOwner(), state -> {
            if (state == null || state.loading) {
                show(progress);
                return;
            }
            if (state.error != null) {
                show(error);
                return;
            }
            show(content);
            adapter.submit(state.categories);
        });

        // Load data
        vm.load();
    }

    private void show(View t) {
        progress.setVisibility(t == progress ? View.VISIBLE : View.GONE);
        error.setVisibility(t == error ? View.VISIBLE : View.GONE);
        content.setVisibility(t == content ? View.VISIBLE : View.GONE);
    }

    // Helper to localize titles
    private static String pick(Map<String, String> map) {
        if (map == null) return "";
        String lang = Locale.getDefault().getLanguage();
        if (map.containsKey(lang)) return map.get(lang);
        if (map.containsKey("ar")) return map.get("ar");
        if (map.containsKey("en")) return map.get("en");
        return map.values().stream().findFirst().orElse("");
    }

    // ==============================
    // Adapter for displaying articles
    // ==============================
    static class CategoriesAdapter extends RecyclerView.Adapter<CategoriesAdapter.ArticleVH> {
        private final List<LibraryModels.ArticleListItem> items = new ArrayList<>();

        void submit(List<LibraryModels.Category> cats) {
            items.clear();
            if (cats != null) {
                for (LibraryModels.Category c : cats) {
                    if (c.articles != null) items.addAll(c.articles);
                }
            }
            notifyDataSetChanged();
        }

        @NonNull
        @Override
        public ArticleVH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_article, parent, false);
            return new ArticleVH(v);
        }

        @Override
        public void onBindViewHolder(@NonNull ArticleVH h, int i) {
            LibraryModels.ArticleListItem a = items.get(i);
            h.title.setText(pick(a.title));
            h.meta.setText(a.duration != null ? a.duration : a.type != null ? a.type : "");

            // الانتقال إلى صفحة المقالة عند الضغط
            h.itemView.setOnClickListener(v -> {
                Bundle b = new Bundle();
                b.putInt("articleId", a.id);
                NavController nav = NavHostFragment.findNavController(
                        (Fragment) parentFragment(v)
                );
                nav.navigate(R.id.articleFragment, b);
            });
        }

        @Override
        public int getItemCount() {
            return items.size();
        }

        static class ArticleVH extends RecyclerView.ViewHolder {
            TextView title, meta;

            ArticleVH(@NonNull View v) {
                super(v);
                title = v.findViewById(R.id.tvTitle);
                meta = v.findViewById(R.id.tvMeta);
            }
        }

        // Helper: get parent fragment safely
        private Fragment parentFragment(View v) {
            Fragment f = null;
            if (v.getContext() instanceof androidx.fragment.app.FragmentActivity) {
                List<Fragment> frags = ((androidx.fragment.app.FragmentActivity) v.getContext())
                        .getSupportFragmentManager().getFragments();
                for (Fragment frag : frags) {
                    if (frag.isVisible()) f = frag;
                }
            }
            return f;
        }
    }
}