package com.sanad.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import androidx.appcompat.app.AppCompatActivity;

import com.sanad.app.R;
import com.sanad.app.data.auth.TokenStore;

public class SplashActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            TokenStore tokenStore = new TokenStore(this);

            if (tokenStore.hasToken()) {
                // ✅ المستخدم مسجل دخول -> افتح MainActivity
                startActivity(new Intent(SplashActivity.this, MainActivity.class));
            } else {
                // ❌ المستخدم غير مسجل -> افتح LoginActivity
                startActivity(new Intent(SplashActivity.this, LoginActivity.class));
            }

            finish();
        }, 1200); // مدة شاشة البداية
    }
}