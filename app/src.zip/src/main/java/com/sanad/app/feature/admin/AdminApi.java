
package com.sanad.app.feature.admin;
import retrofit2.*; import retrofit2.http.*;
public interface AdminApi {
  @GET("api/v1/admin/dashboard") Call<AdminModels.Dashboard> dashboard();
  @GET("api/v1/admin/users") Call<AdminModels.Users> users();
  @GET("api/v1/admin/specialists") Call<AdminModels.Specialists> specialists();
  @GET("api/v1/admin/organizations") Call<AdminModels.Organizations> orgs();
  @GET("api/v1/admin/appointments") Call<AdminModels.Appointments> appointments();
  @GET("api/v1/admin/library/posts") Call<AdminModels.Posts> posts();
  @POST("api/v1/admin/library/posts/{id}/toggle") Call<AdminModels.Toggle> toggle(@Path("id") int id);
  @POST("api/v1/admin/specialists/{id}/approve") Call<AdminModels.Toggle> approveSpec(@Path("id") int id);
  @POST("api/v1/admin/specialists/{id}/reject")  Call<AdminModels.Toggle> rejectSpec(@Path("id") int id);
  @POST("api/v1/admin/organizations/{id}/approve") Call<AdminModels.Toggle> approveOrg(@Path("id") int id);
  @POST("api/v1/admin/organizations/{id}/reject")  Call<AdminModels.Toggle> rejectOrg(@Path("id") int id);
}
