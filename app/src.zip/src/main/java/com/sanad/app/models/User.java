package com.sanad.app.models;
public class User {
    public int id;
    public String name;
    public String email;
    public String role;
}
