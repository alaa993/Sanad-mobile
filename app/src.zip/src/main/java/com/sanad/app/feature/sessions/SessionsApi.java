package com.sanad.app.feature.sessions;
import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;
public interface SessionsApi {
    @GET("api/v1/sessions") Call<SessionModels.SessionList> getSessions();
    @GET("api/v1/sessions/{id}") Call<SessionModels.Session> getSession(@Path("id") int id);

    @POST("api/v1/sessions")
    Call<SessionModels.Session> book(@Body BookRequest req);
}
