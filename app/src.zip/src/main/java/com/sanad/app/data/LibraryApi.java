package com.sanad.app.data;

import java.util.List;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Path;

public interface LibraryApi {
    @GET("api/v1/library")
    Call<List<LibraryModels.Category>> getLibrary();

    @GET("api/v1/library/{id}")
    Call<LibraryModels.ArticleDetail> getArticle(@Path("id") int id);
}
