package com.sanad.app.feature.sessions;
import java.util.List;
public class SessionModels {
    public static class Person { public int id; public String name; }
    public static class Session {
        public int id; public String type; public String status; public String scheduled_at; public String notes;
        public Person specialist; public Person organization; public Person user;
    }
    public static class SessionList { public List<Session> upcoming; public List<Session> history; }
}
