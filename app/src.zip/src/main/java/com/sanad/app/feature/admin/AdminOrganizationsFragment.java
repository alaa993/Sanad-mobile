
package com.sanad.app.feature.admin;
import android.os.Bundle; import android.view.*; import android.widget.*;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider; import androidx.recyclerview.widget.*;
import com.sanad.app.R;
import java.util.*;
public class AdminOrganizationsFragment extends Fragment {
  private AdminViewModels.OrgListVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_admin_organizations, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    RecyclerView rv=v.findViewById(R.id.rv); rv.setLayoutManager(new LinearLayoutManager(requireContext()));
    OrgAdapter ad=new OrgAdapter(new OrgAdapter.Listener(){
      @Override public void onApprove(int id){ vm.approve(id); }
      @Override public void onReject (int id){ vm.reject(id); }
    }); rv.setAdapter(ad);
    vm=new ViewModelProvider(this).get(AdminViewModels.OrgListVM.class);
    vm.list.observe(getViewLifecycleOwner(), ad::submit);
    v.findViewById(R.id.btnRefresh).setOnClickListener(x-> vm.load());
    vm.load();
  }
  static class OrgAdapter extends RecyclerView.Adapter<OrgAdapter.VH> {
    interface Listener{ void onApprove(int id); void onReject(int id); }
    private final List<AdminModels.Organizations.Organization> data=new ArrayList<>(); private final Listener ls;
    OrgAdapter(Listener l){ this.ls=l; }
    void submit(List<AdminModels.Organizations.Organization> d){ data.clear(); if(d!=null) data.addAll(d); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_admin_org,p,false)); }
    @Override public void onBindViewHolder(@NonNull VH h,int i){
      AdminModels.Organizations.Organization o=data.get(i);
      h.title.setText(o.name);
      h.meta.setText("status: "+(o.status!=null?o.status:"-"));
      h.btnApprove.setOnClickListener(x-> ls.onApprove(o.id));
      h.btnReject .setOnClickListener(x-> ls.onReject (o.id));
    }
    @Override public int getItemCount(){ return data.size(); }
    static class VH extends RecyclerView.ViewHolder{
      TextView title, meta; Button btnApprove, btnReject;
      VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta); btnApprove=v.findViewById(R.id.btnApprove); btnReject=v.findViewById(R.id.btnReject); }
    }
  }
}
