package com.sanad.app.models;
public class LoginResponse {
    public boolean ok;
    public String token;
    public User user;
}
