package com.sanad.app.feature.sessions;

public class DirectoryModels {
    public static class Item { public int id; public String name; public String avatar; }
    public static class Paged { public java.util.List<Item> data; }
}
