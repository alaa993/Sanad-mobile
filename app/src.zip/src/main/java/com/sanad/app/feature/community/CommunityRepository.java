
package com.sanad.app.feature.community;
import android.content.Context; import com.sanad.app.data.ApiClient;
import retrofit2.*; import java.util.*;
public class CommunityRepository {
  private final CommunityApi api;
  public CommunityRepository(Context ctx){ api = ApiClient.get(ctx).create(CommunityApi.class); }
  public interface Cb<T>{ void ok(T t); void err(Throwable e); }
  private static <T> Callback<T> wrap(Cb<T> cb){ return new Callback<T>(){
    @Override public void onResponse(Call<T> c, Response<T> r){ if(r.isSuccessful() && r.body()!=null) cb.ok(r.body()); else cb.err(new Exception("HTTP "+r.code())); }
    @Override public void onFailure(Call<T> c, Throwable t){ cb.err(t); }
  };}
  public void communities(Cb<CommunityModels.ListResponse<CommunityModels.Community>> cb){ api.communities().enqueue(wrap(cb)); }
  public void feed(int id, Cb<CommunityModels.ListResponse<CommunityModels.Post>> cb){ api.feed(id).enqueue(wrap(cb)); }
  public void post(int id, String text, Cb<CommunityModels.SimpleResponse> cb){ java.util.Map<String,String> b=new java.util.HashMap<>(); b.put("body",text); api.post(id,b).enqueue(wrap(cb)); }
  public void articles(Cb<CommunityModels.ListResponse<CommunityModels.Article>> cb){ api.articles(null).enqueue(wrap(cb)); }
  public void journal(Cb<CommunityModels.ListResponse<CommunityModels.Journal>> cb){ api.journal().enqueue(wrap(cb)); }
  public void addJournal(String entry, Cb<CommunityModels.SimpleResponse> cb){ java.util.Map<String,String> b=new java.util.HashMap<>(); b.put("entry",entry); api.addJournal(b).enqueue(wrap(cb)); }
  public void delJournal(int id, Cb<CommunityModels.SimpleResponse> cb){ api.delJournal(id).enqueue(wrap(cb)); }
}
