
package com.sanad.app.feature.admin;
public class AdminModels {
  public static class Dashboard { public Counters counters; public static class Counters{ public int users,specialists,organizations,appointments,appointments_today,posts; } }
  public static class Users { public java.util.List<User> data; public static class User{ public int id; public String name,email; } }
  public static class Specialists { public java.util.List<Specialist> data; public static class Specialist{ public int id,years_exp; public String name,specialty,status; public boolean accepting_new; } }
  public static class Organizations { public java.util.List<Organization> data;
    public static class Organization{ public int id; public String name,status; } }
  public static class Appointments { public java.util.List<Appointment> data;
    public static class Appointment{ public int id,specialist_id,patient_id; public String status,starts_at,ends_at; } }
  public static class Posts { public java.util.List<Post> data; public static class Post{ public int id; public String title,status; } }
  public static class Toggle { public Boolean ok; public String status; }
}
