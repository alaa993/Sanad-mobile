
package com.sanad.app.feature.specialist;
import android.content.Context; import com.sanad.app.data.ApiClient;
import retrofit2.*; 
public class SpecialistRepository {
  private final SpecialistApi api;
  public SpecialistRepository(Context ctx){ api = ApiClient.get(ctx).create(SpecialistApi.class); }
  public interface Cb<T>{ void ok(T t); void err(Throwable e); }
  private static <T> Callback<T> wrap(Cb<T> cb){ return new Callback<T>(){ @Override public void onResponse(Call<T> c, Response<T> r){ if(r.isSuccessful()&&r.body()!=null) cb.ok(r.body()); else cb.err(new Exception("HTTP "+r.code())); } @Override public void onFailure(Call<T> c, Throwable t){ cb.err(t); } }; }
  public void dashboard(Cb<SpecialistModels.Dashboard> cb){ api.dashboard().enqueue(wrap(cb)); }
  public void sessions(String scope, Cb<SpecialistModels.Appointments> cb){ api.sessions(scope).enqueue(wrap(cb)); }
  public void accept(int id, Cb<SpecialistModels.Simple> cb){ api.accept(id).enqueue(wrap(cb)); }
  public void reject(int id, Cb<SpecialistModels.Simple> cb){ api.reject(id).enqueue(wrap(cb)); }
  public void reschedule(int id, String starts, String ends, Cb<SpecialistModels.Simple> cb){ java.util.Map<String,Object> b=new java.util.HashMap<>(); b.put("starts_at",starts); b.put("ends_at",ends); api.reschedule(id,b).enqueue(wrap(cb)); }
  public void profile(SpecialistRepository.Cb<SpecialistModels.Profile> cb){ api.profile().enqueue(wrap(cb)); }
  public void update(java.util.Map<String,Object> body, Cb<SpecialistModels.Simple> cb){ api.update(body).enqueue(wrap(cb)); }
}
