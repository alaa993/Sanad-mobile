
package com.sanad.app.feature.specialist;
import retrofit2.*; import retrofit2.http.*; import java.util.*; 
public interface SpecialistApi {
  @GET("api/v1/specialist/dashboard") Call<SpecialistModels.Dashboard> dashboard();
  @GET("api/v1/specialist/sessions") Call<SpecialistModels.Appointments> sessions(@Query("scope") String scope);
  @POST("api/v1/specialist/sessions/{id}/accept") Call<SpecialistModels.Simple> accept(@Path("id") int id);
  @POST("api/v1/specialist/sessions/{id}/reject") Call<SpecialistModels.Simple> reject(@Path("id") int id);
  @POST("api/v1/specialist/sessions/{id}/reschedule") Call<SpecialistModels.Simple> reschedule(@Path("id") int id, @Body Map<String,Object> body);
  @GET("api/v1/specialist/profile") Call<SpecialistModels.Profile> profile();
  @PUT("api/v1/specialist/profile") Call<SpecialistModels.Simple> update(@Body Map<String,Object> body);
}
