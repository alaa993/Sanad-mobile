
package com.sanad.app.feature.org;
import android.os.Bundle; import android.view.*; import android.widget.TextView;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager; import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R;
public class OrgSpecialistsFragment extends Fragment {
  private OrgViewModels.SpecialistsVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_org_specialists, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    RecyclerView rv=v.findViewById(R.id.rv); rv.setLayoutManager(new LinearLayoutManager(requireContext())); Adapter ad=new Adapter(); rv.setAdapter(ad);
    vm=new ViewModelProvider(this).get(OrgViewModels.SpecialistsVM.class);
    vm.list.observe(getViewLifecycleOwner(), ad::submit); vm.load();
  }
  static class Adapter extends RecyclerView.Adapter<Adapter.VH>{
    private final java.util.List<OrgModels.Specialist> data=new java.util.ArrayList<>();
    void submit(java.util.List<OrgModels.Specialist> d){ data.clear(); if(d!=null) data.addAll(d); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_org_specialist,p,false)); }
    @Override public void onBindViewHolder(@NonNull VH h,int i){ var s=data.get(i); h.title.setText(s.name); h.meta.setText(s.role); }
    @Override public int getItemCount(){ return data.size(); }
    static class VH extends RecyclerView.ViewHolder{ TextView title,meta; VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta);} }
  }
}
