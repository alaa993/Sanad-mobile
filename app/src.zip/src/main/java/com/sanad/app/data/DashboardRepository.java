package com.sanad.app.data;

import android.content.Context;
import com.sanad.app.data.auth.AuthInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardRepository {
    private final ApiService api;

    public DashboardRepository(Context context) {
        api = new Retrofit.Builder()
                .baseUrl(AppConfig.BASE_URL)
                .client(new OkHttpClient.Builder()
                        .addInterceptor(new AuthInterceptor(context))
                        .build())
                .addConverterFactory(GsonConverterFactory.create())
                .build()
                .create(ApiService.class);
    }

    public interface Listener {
        void onSuccess(DashboardResponse d);
        void onError(Throwable t);
    }

    public void fetch(Listener l) {
        api.getDashboard().enqueue(new Callback<DashboardResponse>() {
            @Override
            public void onResponse(Call<DashboardResponse> call, Response<DashboardResponse> r) {
                if (!r.isSuccessful() || r.body() == null) {
                    l.onError(new RuntimeException("bad_response"));
                    return;
                }
                l.onSuccess(r.body());
            }

            @Override
            public void onFailure(Call<DashboardResponse> call, Throwable t) {
                l.onError(t);
            }
        });
    }
}