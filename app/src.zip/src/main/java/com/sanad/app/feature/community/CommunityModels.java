
package com.sanad.app.feature.community;
import java.util.List; import java.util.Map;
public class CommunityModels {
  public static class Community { public int id; public String slug; public Map<String,String> name; public Map<String,String> about; public String visibility; public int members_count; public boolean joined; }
  public static class Author { public int id; public String name; }
  public static class Post { public int id; public String body; public Author author; public String created_at; }
  public static class Article { public int id; public String slug; public Map<String,String> title; public List<String> tags; public String created_at; public Map<String,String> body; }
  public static class Journal { public int id; public String entry; public String created_at; }
  public static class ListResponse<T> { public List<T> data; }
  public static class SimpleResponse { public Boolean joined; public Boolean favorited; public Boolean deleted; public Integer id; public String created_at; }
}
