package com.sanad.app.data;

import android.content.Context;
import androidx.annotation.NonNull;

import com.sanad.app.data.auth.AuthInterceptor;
import java.util.List;
import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class LibraryRepository {
    private final LibraryApi api;

    public LibraryRepository(Context ctx) {
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppConfig.BASE_URL)
                .client(new OkHttpClient.Builder()
                        .addInterceptor(new AuthInterceptor(ctx))
                        .build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        api = retrofit.create(LibraryApi.class);
    }

    public interface ListListener {
        void onSuccess(List<LibraryModels.Category> data);
        void onError(Throwable t);
    }
    public interface ArticleListener {
        void onSuccess(LibraryModels.ArticleDetail detail);
        void onError(Throwable t);
    }

    public void fetchLibrary(ListListener l){
        api.getLibrary().enqueue(new Callback<List<LibraryModels.Category>>() {
            @Override public void onResponse(@NonNull Call<List<LibraryModels.Category>> call, @NonNull Response<List<LibraryModels.Category>> r) {
                if (!r.isSuccessful() || r.body()==null) { l.onError(new RuntimeException("bad_response")); return; }
                l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<List<LibraryModels.Category>> call, @NonNull Throwable t) { l.onError(t); }
        });
    }

    public void fetchArticle(int id, ArticleListener l){
        api.getArticle(id).enqueue(new Callback<LibraryModels.ArticleDetail>() {
            @Override public void onResponse(@NonNull Call<LibraryModels.ArticleDetail> call, @NonNull Response<LibraryModels.ArticleDetail> r) {
                if (!r.isSuccessful() || r.body()==null) { l.onError(new RuntimeException("bad_response")); return; }
                l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<LibraryModels.ArticleDetail> call, @NonNull Throwable t) { l.onError(t); }
        });
    }
}
