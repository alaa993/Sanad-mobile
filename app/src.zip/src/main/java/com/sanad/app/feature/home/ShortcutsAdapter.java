package com.sanad.app.feature.home;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R;
import com.sanad.app.data.DashboardResponse;
import java.util.ArrayList;
import java.util.List;

public class ShortcutsAdapter extends RecyclerView.Adapter<ShortcutsAdapter.VH> {
    public interface OnClick { void onShortcut(DashboardResponse.Shortcut s); }
    private final List<DashboardResponse.Shortcut> data = new ArrayList<>();
    private OnClick click;

    public void setOnClick(OnClick c) { this.click = c; }
    public void submit(List<DashboardResponse.Shortcut> d) {
        data.clear(); if (d!=null) data.addAll(d); notifyDataSetChanged();
    }

    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
        return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_shortcut, p, false));
    }

    @Override public void onBindViewHolder(@NonNull VH h, int i) {
        DashboardResponse.Shortcut s = data.get(i);
        h.title.setText(s.title);
        h.itemView.setOnClickListener(v -> { if (click!=null) click.onShortcut(s); });
    }

    @Override public int getItemCount(){ return data.size(); }

    static class VH extends RecyclerView.ViewHolder {
        TextView title;
        VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); }
    }
}