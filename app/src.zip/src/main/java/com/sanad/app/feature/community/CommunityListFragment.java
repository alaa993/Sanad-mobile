package com.sanad.app.feature.community;
import android.os.Bundle; import android.view.*; import android.widget.TextView;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager; import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R; import java.util.*;
public class CommunityListFragment extends Fragment {
  private CommunityViewModels.CommunityListVM vm; private RecyclerView rv;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState){ return inflater.inflate(R.layout.fragment_community_list, container, false); }
  @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s){
    super.onViewCreated(v,s);
    rv = v.findViewById(R.id.rvCommunities); rv.setLayoutManager(new LinearLayoutManager(requireContext()));
    Adapter ad = new Adapter(); rv.setAdapter(ad);
    vm = new ViewModelProvider(this).get(CommunityViewModels.CommunityListVM.class);
    vm.list.observe(getViewLifecycleOwner(), ad::submit); vm.load();
  }
  static class Adapter extends RecyclerView.Adapter<Adapter.VH> {
    private final List<CommunityModels.Community> data = new ArrayList<>();
    void submit(List<CommunityModels.Community> d){ data.clear(); if(d!=null) data.addAll(d); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_community, p, false)); }
    @Override public void onBindViewHolder(@NonNull VH h, int i){
      CommunityModels.Community c = data.get(i);
      String title = c.name!=null ? (c.name.get("ar")!=null? c.name.get("ar") : (c.name.get("en")!=null? c.name.get("en") : c.slug)) : c.slug;
      String about = c.about!=null ? (c.about.get("ar")!=null? c.about.get("ar") : (c.about.get("en")!=null? c.about.get("en") : "")) : "";
      h.title.setText(title); h.meta.setText(about);
      h.itemView.setOnClickListener(v -> {
        Bundle b = new Bundle(); b.putInt("communityId", c.id); b.putString("communityTitle", title);
        androidx.navigation.NavController nav = androidx.navigation.fragment.NavHostFragment.findNavController(new NavHostFragment());
        nav.navigate(R.id.communityFeedFragment, b);
      });
    }
    @Override public int getItemCount(){ return data.size(); }
    static class VH extends RecyclerView.ViewHolder { TextView title, meta; VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta); } }
  }
}
