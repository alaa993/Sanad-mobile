
package com.sanad.app.feature.org;
import android.content.Context; import com.sanad.app.data.ApiClient;
import retrofit2.*;
public class OrgRepository {
  private final OrgApi api;
  public OrgRepository(Context ctx){ api = ApiClient.get(ctx).create(OrgApi.class); }
  public interface Cb<T>{ void ok(T t); void err(Throwable e); }
  private static <T> Callback<T> wrap(Cb<T> cb){ return new Callback<T>(){ @Override public void onResponse(Call<T> c, Response<T> r){ if(r.isSuccessful()&&r.body()!=null) cb.ok(r.body()); else cb.err(new Exception("HTTP "+r.code())); } @Override public void onFailure(Call<T> c, Throwable t){ cb.err(t); } }; }
  public void dashboard(Cb<OrgModels.Dashboard> cb){ api.dashboard().enqueue(wrap(cb)); }
  public void specialists(Cb<OrgModels.Specialists> cb){ api.specialists().enqueue(wrap(cb)); }
  public void sessions(Cb<OrgModels.Appointments> cb){ api.sessions().enqueue(wrap(cb)); }
}
