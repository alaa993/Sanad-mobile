package com.sanad.app.data.auth;

import com.sanad.app.models.LoginRequest;
import com.sanad.app.models.LoginResponse;
import com.sanad.app.models.User;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.GET;
import retrofit2.http.POST;

public interface AuthApi {
    @POST("/api/auth/login")
    Call<LoginResponse> login(@Body LoginRequest body);

    @GET("/api/auth/me")
    Call<User> me();

    @POST("/api/auth/logout")
    Call<Void> logout();
}
