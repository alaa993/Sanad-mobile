
package com.sanad.app.feature.specialist;
import android.app.Application; import androidx.annotation.NonNull; import androidx.lifecycle.*;
public class SpecialistViewModels {
  public static class HomeVM extends AndroidViewModel {
    public MutableLiveData<SpecialistModels.Dashboard> state = new MutableLiveData<>(); private final SpecialistRepository repo;
    public HomeVM(@NonNull Application app){ super(app); repo = new SpecialistRepository(app); }
    public void load(){ repo.dashboard(new SpecialistRepository.Cb<SpecialistModels.Dashboard>(){ @Override public void ok(SpecialistModels.Dashboard t){ state.postValue(t);} @Override public void err(Throwable e){} }); }
  }
  public static class SessionsVM extends AndroidViewModel {
    public MutableLiveData<java.util.List<SpecialistModels.Appointment>> list = new MutableLiveData<>(new java.util.ArrayList<>()); private final SpecialistRepository repo;
    public SessionsVM(@NonNull Application app){ super(app); repo = new SpecialistRepository(app); }
    public void load(String scope){ repo.sessions(scope, new SpecialistRepository.Cb<SpecialistModels.Appointments>(){ @Override public void ok(SpecialistModels.Appointments t){ list.postValue(t.data);} @Override public void err(Throwable e){} }); }
  }
  public static class ProfileVM extends AndroidViewModel {
    public MutableLiveData<SpecialistModels.Profile> state = new MutableLiveData<>(); private final SpecialistRepository repo;
    public ProfileVM(@NonNull Application app){ super(app); repo = new SpecialistRepository(app); }
    public void load(){ repo.profile(new SpecialistRepository.Cb<SpecialistModels.Profile>(){ @Override public void ok(SpecialistModels.Profile t){ state.postValue(t);} @Override public void err(Throwable e){} }); }
    public void update(java.util.Map<String,Object> body){ repo.update(body, new SpecialistRepository.Cb<SpecialistModels.Simple>(){ @Override public void ok(SpecialistModels.Simple t){ load(); } @Override public void err(Throwable e){} }); }
  }
}
