package com.sanad.app.feature.library;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.sanad.app.data.LibraryModels;
import com.sanad.app.data.LibraryRepository;

import java.util.List;

public class LibraryViewModel extends AndroidViewModel {
    private final LibraryRepository repo;
    public LibraryViewModel(@NonNull Application app){ super(app); repo=new LibraryRepository(app); }

    public static class UIState {
        public boolean loading;
        public String error;
        public List<LibraryModels.Category> categories;
        public static UIState loading(){ UIState s=new UIState(); s.loading=true; return s; }
        public static UIState error(String e){ UIState s=new UIState(); s.error=e; return s; }
        public static UIState data(List<LibraryModels.Category> c){ UIState s=new UIState(); s.categories=c; return s; }
    }

    private final MutableLiveData<UIState> state = new MutableLiveData<>(UIState.loading());
    public LiveData<UIState> getState(){ return state; }

    public void load(){
        state.postValue(UIState.loading());
        repo.fetchLibrary(new LibraryRepository.ListListener() {
            @Override public void onSuccess(List<LibraryModels.Category> data) { state.postValue(UIState.data(data)); }
            @Override public void onError(Throwable t) { state.postValue(UIState.error(t.getMessage())); }
        });
    }
}
