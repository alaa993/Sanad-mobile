
package com.sanad.app.feature.org;
public class OrgModels {
  public static class Dashboard { public Counters counters; public Integer org_id; public static class Counters{ public int upcoming; public int pending; } }
  public static class Specialist { public int id; public String name; public String role; }
  public static class Specialists { public java.util.List<Specialist> data; }
  public static class Appointment { public int id; public String status; public String starts_at; public String ends_at; public int specialist_id; public int patient_id; }
  public static class Appointments { public java.util.List<Appointment> data; }
}
