package com.sanad.app.data;

import java.util.Map;
import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiService {
    @GET("api/v1/ping")
    Call<Map<String,Object>> ping();

    @GET("api/v1/bootstrap")
    Call<Map<String,Object>> bootstrap();

    @GET("api/v1/dashboard")
    Call<DashboardResponse> getDashboard();
}

