package com.sanad.app.feature.sessions;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R;
import java.util.ArrayList;
import java.util.List;

public class SessionsFragment extends Fragment {
    private SessionsViewModel vm;
    private View progress, error, content;
    private RecyclerView rvUpcoming, rvHistory;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_sessions, container, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        progress = v.findViewById(R.id.progress);
        error    = v.findViewById(R.id.errorContainer);
        content  = v.findViewById(R.id.content);

        rvUpcoming = v.findViewById(R.id.rvUpcoming);
        rvHistory  = v.findViewById(R.id.rvHistory);

        rvUpcoming.setLayoutManager(new LinearLayoutManager(requireContext()));
        rvHistory.setLayoutManager(new LinearLayoutManager(requireContext()));

        SessionAdapter up = new SessionAdapter(this);
        SessionAdapter hi = new SessionAdapter(this);
        rvUpcoming.setAdapter(up);
        rvHistory.setAdapter(hi);

        vm = new ViewModelProvider(this).get(SessionsViewModel.class);
        vm.getState().observe(getViewLifecycleOwner(), st -> {
            if (st==null || st.loading){ show(progress); return; }
            if (st.error!=null){ show(error); return; }
            show(content);
            up.submit(st.data.upcoming);
            hi.submit(st.data.history);
        });

        v.findViewById(R.id.btnRetry).setOnClickListener(x -> vm.load());
        vm.load();


    }

    private void show(View t){
        progress.setVisibility(t==progress?View.VISIBLE:View.GONE);
        error.setVisibility(t==error?View.VISIBLE:View.GONE);
        content.setVisibility(t==content?View.VISIBLE:View.GONE);
    }

    static class SessionAdapter extends RecyclerView.Adapter<SessionAdapter.VH> {
        private final List<SessionModels.Session> data = new ArrayList<>();
        private final Fragment host;
        SessionAdapter(Fragment host){ this.host = host; }
        void submit(List<SessionModels.Session> d){ data.clear(); if (d!=null) data.addAll(d); notifyDataSetChanged(); }

        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v) {
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_session, p, false));
        }
        @Override public void onBindViewHolder(@NonNull VH h, int i) {
            SessionModels.Session s = data.get(i);
            h.title.setText(s.type + " · " + s.status);
            h.meta.setText(s.scheduled_at);
            h.itemView.setOnClickListener(v -> {
                Bundle b = new Bundle(); b.putInt("sessionId", s.id);
                NavController nav = NavHostFragment.findNavController(host);
                nav.navigate(R.id.sessionDetailFragment, b);
            });
        }
        @Override public int getItemCount(){ return data.size(); }
        static class VH extends RecyclerView.ViewHolder {
            TextView title, meta;
            VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta); }
        }
    }
}
