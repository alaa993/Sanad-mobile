package com.sanad.app.feature.home;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.sanad.app.data.DashboardRepository;
import com.sanad.app.data.DashboardResponse;

public class HomeViewModel extends AndroidViewModel {

    private final MutableLiveData<UIState> state = new MutableLiveData<>(UIState.loading());
    private final DashboardRepository repo;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        repo = new DashboardRepository(application.getApplicationContext()); // ✅ تمرير Context صالح
    }

    public LiveData<UIState> getState() {
        return state;
    }

    public void load() {
        state.postValue(UIState.loading());
        repo.fetch(new DashboardRepository.Listener() {
            @Override
            public void onSuccess(DashboardResponse d) {
                int up = d.stats != null ? d.stats.upcoming_sessions : 0;
                int un = d.stats != null ? d.stats.unread_messages : 0;
                int pt = d.stats != null ? d.stats.points : 0;
                state.postValue(UIState.data(d.role, up, un, pt, d.shortcuts));
            }

            @Override
            public void onError(Throwable t) {
                state.postValue(UIState.error(t));
            }
        });
    }
}