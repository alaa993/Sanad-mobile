
package com.sanad.app.feature.community;
import retrofit2.Call; import retrofit2.http.*; import java.util.Map;
public interface CommunityApi {
  @GET("api/v1/community") Call<CommunityModels.ListResponse<CommunityModels.Community>> communities();
  @GET("api/v1/community/{id}/feed") Call<CommunityModels.ListResponse<CommunityModels.Post>> feed(@Path("id") int id);
  @POST("api/v1/community/{id}/post") Call<CommunityModels.SimpleResponse> post(@Path("id") int id, @Body Map<String,String> body);
  @GET("api/v1/articles") Call<CommunityModels.ListResponse<CommunityModels.Article>> articles(@Query("tag") String tag);
  @GET("api/v1/articles/{id}") Call<CommunityModels.ListResponse<CommunityModels.Article>> article(@Path("id") int id);
  @GET("api/v1/journal") Call<CommunityModels.ListResponse<CommunityModels.Journal>> journal();
  @POST("api/v1/journal") Call<CommunityModels.SimpleResponse> addJournal(@Body Map<String,String> body);
  @DELETE("api/v1/journal/{id}") Call<CommunityModels.SimpleResponse> delJournal(@Path("id") int id);
}
