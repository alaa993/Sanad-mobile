package com.sanad.app.feature.admin;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.*;
public class AdminViewModels {
  public static class HomeVM extends AndroidViewModel {
    public MutableLiveData<AdminModels.Dashboard> state=new MutableLiveData<>();
    private final AdminRepository repo; public HomeVM(@NonNull Application app){ super(app); repo=new AdminRepository(app); }
    public void load(){ repo.dashboard(new AdminRepository.Cb<AdminModels.Dashboard>(){ public void ok(AdminModels.Dashboard t){ state.postValue(t);} public void err(Throwable e){} }); }
  }
  public static class SpecListVM extends AndroidViewModel {
    public MutableLiveData<java.util.List<AdminModels.Specialists.Specialist>> list=new MutableLiveData<>(new java.util.ArrayList<>());
    private final AdminRepository repo; public SpecListVM(@NonNull Application app){ super(app); repo=new AdminRepository(app); }
    public void load(){ repo.specialists(new AdminRepository.Cb<AdminModels.Specialists>(){ public void ok(AdminModels.Specialists t){ list.postValue(t.data);} public void err(Throwable e){} }); }
    public void approve(int id){ repo.approveSpec(id, new AdminRepository.Cb<AdminModels.Toggle>(){ public void ok(AdminModels.Toggle t){ load(); } public void err(Throwable e){} }); }
    public void reject (int id){ repo.rejectSpec(id,  new AdminRepository.Cb<AdminModels.Toggle>(){ public void ok(AdminModels.Toggle t){ load(); } public void err(Throwable e){} }); }
  }
  public static class OrgListVM extends AndroidViewModel {
    public MutableLiveData<java.util.List<AdminModels.Organizations.Organization>> list=new MutableLiveData<>(new java.util.ArrayList<>());
    private final AdminRepository repo; public OrgListVM(@NonNull Application app){ super(app); repo=new AdminRepository(app); }
    public void load(){ repo.orgs(new AdminRepository.Cb<AdminModels.Organizations>(){ public void ok(AdminModels.Organizations t){ list.postValue(t.data);} public void err(Throwable e){} }); }
    public void approve(int id){ repo.approveOrg(id, new AdminRepository.Cb<AdminModels.Toggle>(){ public void ok(AdminModels.Toggle t){ load(); } public void err(Throwable e){} }); }
    public void reject (int id){ repo.rejectOrg(id,  new AdminRepository.Cb<AdminModels.Toggle>(){ public void ok(AdminModels.Toggle t){ load(); } public void err(Throwable e){} }); }
  }
}
