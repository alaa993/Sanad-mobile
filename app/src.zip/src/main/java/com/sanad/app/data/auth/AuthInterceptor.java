package com.sanad.app.data.auth;

import android.content.Context;
import java.io.IOException;
import okhttp3.Interceptor;
import okhttp3.Request;
import okhttp3.Response;

public class AuthInterceptor implements Interceptor {
    private final TokenStore tokenStore;

    public AuthInterceptor(Context context) {
        this.tokenStore = new TokenStore(context);
    }

    @Override
    public Response intercept(Chain chain) throws IOException {
        Request original = chain.request();
        String token = tokenStore.getToken();
        if (token != null && !token.isEmpty()) {
            Request withAuth = original.newBuilder()
                    .addHeader("Authorization", "Bearer " + token)
                    .build();
            return chain.proceed(withAuth);
        }
        return chain.proceed(original);
    }
}
