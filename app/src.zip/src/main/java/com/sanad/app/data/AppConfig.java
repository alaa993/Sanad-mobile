package com.sanad.app.data;

import android.app.Application;
import android.content.Context;

public class AppConfig extends Application {
    private static Context context;

    @Override
    public void onCreate() {
        super.onCreate();
        context = getApplicationContext();
    }

    public static Context getContext() {
        return context;
    }

    public static final String BASE_URL = "https://romantic-hawking.52-91-29-105.plesk.page/";
}