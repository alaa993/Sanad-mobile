package com.sanad.app.data;

import java.util.List;

public class DashboardResponse {
    public String role;
    public Stats stats;
    public List<Shortcut> shortcuts;

    public static class Stats {
        public int upcoming_sessions;
        public int unread_messages;
        public int points;
    }

    public static class Shortcut {
        public String id;
        public String title;
        public String route;
    }
}
