
package com.sanad.app.feature.billing;
import retrofit2.*; import retrofit2.http.*; import java.util.*;
public interface BillingApi {
  @GET("api/v1/billing/plans") Call<PlansResponse> plans();
  @POST("api/v1/billing/subscribe") @FormUrlEncoded Call<GenericResponse> subscribe(@Field("plan_id") int planId);
  @POST("api/v1/billing/cancel") Call<GenericResponse> cancel();
  @GET("api/v1/wallet/me") Call<WalletResponse> wallet();
  @POST("api/v1/wallet/topup/intent") @FormUrlEncoded Call<IntentResponse> createIntent(@Field("amount") int amount);
  @POST("api/v1/wallet/apply-coupon") @FormUrlEncoded Call<CouponResponse> applyCoupon(@Field("code") String code);
  @POST("api/v1/sessions/{id}/confirm-payment") @FormUrlEncoded Call<GenericResponse> confirmSession(@Path("id") int id, @Field("method") String method, @Field("coupon") String coupon);
  @GET("api/v1/billing/transactions") Call<TransactionsResponse> transactions();
  class GenericResponse { public Boolean ok; public String msg; public Integer paid; }
  class PlansResponse { public java.util.List<Plan> data; }
  class Plan { public int id; public String slug,type,cycle,currency; public int price; public String features; }
  class WalletResponse { public int balance; public int points; public java.util.List<Tx> transactions; }
  class Tx { public int id, amount; public String type,status,currency; public String created_at; }
  class IntentResponse { public Boolean ok; public String client_secret; }
  class CouponResponse { public Boolean ok; public Coupon coupon; public String msg; }
  class Coupon { public String code; public Integer percent_off; public Integer amount_off; public String expires_at; }
  class TransactionsResponse { public java.util.List<Tx> data; }
}
