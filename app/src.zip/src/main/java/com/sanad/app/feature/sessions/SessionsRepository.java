package com.sanad.app.feature.sessions;
import android.content.Context;
import androidx.annotation.NonNull;
import com.sanad.app.data.AppConfig;
import com.sanad.app.data.auth.AuthInterceptor;
import okhttp3.OkHttpClient;
import retrofit2.*;
import retrofit2.converter.gson.GsonConverterFactory;

public class SessionsRepository {
    private final SessionsApi api;
    public SessionsRepository(Context ctx){
        Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(AppConfig.BASE_URL)
            .client(new OkHttpClient.Builder().addInterceptor(new AuthInterceptor(ctx)).build())
            .addConverterFactory(GsonConverterFactory.create())
            .build();
        api = retrofit.create(SessionsApi.class);
    }
    public interface ListListener{ void onSuccess(SessionModels.SessionList d); void onError(Throwable t); }
    public interface OneListener{ void onSuccess(SessionModels.Session d); void onError(Throwable t); }

    public void list(ListListener l){
        api.getSessions().enqueue(new Callback<SessionModels.SessionList>(){
            @Override public void onResponse(@NonNull Call<SessionModels.SessionList> c, @NonNull Response<SessionModels.SessionList> r){
                if(!r.isSuccessful()||r.body()==null){ l.onError(new RuntimeException("bad_response")); return; } l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<SessionModels.SessionList> c, @NonNull Throwable t){ l.onError(t); }
        });
    }
    public void show(int id, OneListener l){
        api.getSession(id).enqueue(new Callback<SessionModels.Session>(){
            @Override public void onResponse(@NonNull Call<SessionModels.Session> c, @NonNull Response<SessionModels.Session> r){
                if(!r.isSuccessful()||r.body()==null){ l.onError(new RuntimeException("bad_response")); return; } l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<SessionModels.Session> c, @NonNull Throwable t){ l.onError(t); }
        });
    }
}
