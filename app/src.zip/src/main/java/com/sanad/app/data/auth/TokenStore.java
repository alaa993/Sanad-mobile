package com.sanad.app.data.auth;

import android.content.Context;
import android.content.SharedPreferences;

public class TokenStore {
    private static final String PREF = "sanad_prefs";
    private static final String KEY = "access_token";
    private final SharedPreferences sp;

    public TokenStore(Context context) {
        sp = context.getSharedPreferences(PREF, Context.MODE_PRIVATE);
    }

    public void saveToken(String token) { sp.edit().putString(KEY, token).apply(); }
    public String getToken() { return sp.getString(KEY, null); }
    public void clear() { sp.edit().remove(KEY).apply(); }
    public boolean hasToken() { String t = getToken(); return t != null && !t.isEmpty(); }
}
