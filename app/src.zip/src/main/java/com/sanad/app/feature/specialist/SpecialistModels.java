
package com.sanad.app.feature.specialist;
public class SpecialistModels {
  public static class Dashboard { public Counters counters; public static class Counters{ public int upcoming; public int today; public int pending; } }
  public static class Appointment { public int id; public String status; public String starts_at; public String ends_at; public int patient_id; }
  public static class Appointments { public java.util.List<Appointment> data; }
  public static class Profile { public int id; public int user_id; public String specialty; public java.util.List<String> languages; public int years_exp; public boolean accepting_new; public java.util.Map<String,String> bio; public int rate_cents; public String currency; }
  public static class Simple { public Boolean ok; }
}
