package com.sanad.app.feature.chat;
import android.os.*;
public class ChatRealtime {
    public interface TickListener { void onTick(); }
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable task;
    public void startPolling(TickListener l, long intervalMs){
        stop();
        task = new Runnable(){ @Override public void run(){ l.onTick(); handler.postDelayed(this, intervalMs); } };
        handler.post(task);
    }
    public void stop(){ if(task!=null) handler.removeCallbacks(task); task=null; }
}
