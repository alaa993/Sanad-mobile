package com.sanad.app.feature.sessions;
import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface DirectoryApi {
    @GET("api/v1/specialists")
    Call<DirectoryModels.Paged> specialists(@Query("search") String search, @Query("page") Integer page);
    @GET("api/v1/organizations")
    Call<DirectoryModels.Paged> organizations(@Query("search") String search, @Query("page") Integer page);
}
