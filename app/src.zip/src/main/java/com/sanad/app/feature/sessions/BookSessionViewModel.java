package com.sanad.app.feature.sessions;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.*;

public class BookSessionViewModel extends AndroidViewModel {
    private final SessionsRepository_Book repo;
    public BookSessionViewModel(@NonNull Application app){ super(app); repo = new SessionsRepository_Book(app); }

    public static class UIState {
        public boolean loading; public String error; public SessionModels.Session data;
        public static UIState idle(){ return new UIState(); }
        public static UIState loading(){ UIState s=new UIState(); s.loading=true; return s; }
        public static UIState error(String e){ UIState s=new UIState(); s.error=e; return s; }
        public static UIState data(SessionModels.Session d){ UIState s=new UIState(); s.data=d; return s; }
    }

    private final MutableLiveData<UIState> state = new MutableLiveData<>(UIState.idle());
    public LiveData<UIState> getState(){ return state; }

    public void book(String type, String isoDateTime, Integer specialistId, Integer organizationId, String notes){
        state.postValue(UIState.loading());
        BookRequest req = new BookRequest();
        req.type = type;
        req.scheduled_at = isoDateTime;
        req.specialist_id = specialistId;
        req.organization_id = organizationId;
        req.notes = notes;

        repo.book(req, new SessionsRepository_Book.BookListener() {
            @Override public void onSuccess(SessionModels.Session d){ state.postValue(UIState.data(d)); }
            @Override public void onError(Throwable t){ state.postValue(UIState.error(t.getMessage())); }
        });
    }
}
