
package com.sanad.app.feature.org;
import retrofit2.*; import retrofit2.http.*;
public interface OrgApi {
  @GET("api/v1/org/dashboard") Call<OrgModels.Dashboard> dashboard();
  @GET("api/v1/org/specialists") Call<OrgModels.Specialists> specialists();
  @GET("api/v1/org/sessions") Call<OrgModels.Appointments> sessions();
}
