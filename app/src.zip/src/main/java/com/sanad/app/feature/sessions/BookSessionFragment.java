package com.sanad.app.feature.sessions;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;

import com.sanad.app.R;
import com.sanad.app.data.AppConfig;
import com.sanad.app.data.auth.AuthInterceptor;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import okhttp3.OkHttpClient;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.http.Body;
import retrofit2.http.POST;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * BookSessionFragment
 * - يفتح Pickers لاختيار الأخصائي/المنظمة
 * - يختار التاريخ والوقت
 * - يرسل POST /api/v1/sessions إلى Laravel (therapy_sessions)
 */
public class BookSessionFragment extends Fragment {

    // أسماء المفاتيح القادمة من SelectListFragment
    public static final String FRAGMENT_RESULT_KEY = "picker";

    private EditText etSpecialistId, etOrganizationId, etDate, etTime, etNotes;
    private ProgressBar progress;
    private boolean pickingSpecialist = true; // لمعرفة أي زر تم فتحه

    // وقت الحجز المختار
    private final Calendar cal = Calendar.getInstance();

    // --- Retrofit API مضمّن داخل الملف لتبسيط الدمج ---
    private interface SessionsApi {
        @POST("api/v1/sessions")
        Call<Map<String, Object>> create(@Body Map<String, Object> body);
    }

    private SessionsApi api;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_book_session, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);

        // ربط الواجهات
        Button btnPickSpecialist   = v.findViewById(R.id.btnPickSpecialist);
        Button btnPickOrganization = v.findViewById(R.id.btnPickOrganization);
        Button btnPickDate         = v.findViewById(R.id.btnPickDate);
        Button btnPickTime         = v.findViewById(R.id.btnPickTime);
        Button btnConfirm          = v.findViewById(R.id.btnConfirm);

        etSpecialistId   = v.findViewById(R.id.etSpecialistId);
        etOrganizationId = v.findViewById(R.id.etOrganizationId);
        etDate           = v.findViewById(R.id.etDate);
        etTime           = v.findViewById(R.id.etTime);
        etNotes          = v.findViewById(R.id.etNotes);
        progress         = v.findViewById(R.id.progress);

        // Retrofit مع الـ AuthInterceptor
        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(AppConfig.BASE_URL)
                .client(new OkHttpClient.Builder()
                        .addInterceptor(new AuthInterceptor(requireContext()))
                        .build())
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        api = retrofit.create(SessionsApi.class);

        // استقبال نتيجة الـ Picker (أخصائي/منظمة)
        getParentFragmentManager().setFragmentResultListener(FRAGMENT_RESULT_KEY, this, (key, b) -> {
            int id = b.getInt(SelectListFragment.RESULT_ID);
            String name = b.getString(SelectListFragment.RESULT_NAME);
            if (pickingSpecialist) {
                etSpecialistId.setText(String.valueOf(id));
                etSpecialistId.setTag(name);
            } else {
                etOrganizationId.setText(String.valueOf(id));
                etOrganizationId.setTag(name);
            }
        });

        // فتح اختيار الأخصائي
        btnPickSpecialist.setOnClickListener(x -> {
            pickingSpecialist = true;
            Bundle args = new Bundle();
            args.putBoolean(SelectListFragment.ARG_IS_SPECIALISTS, true);
            NavController nav = NavHostFragment.findNavController(this);
            nav.navigate(R.id.selectSpecialistFragment, args);
        });

        // فتح اختيار المنظمة
        btnPickOrganization.setOnClickListener(x -> {
            pickingSpecialist = false;
            Bundle args = new Bundle();
            args.putBoolean(SelectListFragment.ARG_IS_SPECIALISTS, false);
            NavController nav = NavHostFragment.findNavController(this);
            nav.navigate(R.id.selectOrganizationFragment, args);
        });

        // اختيار التاريخ
        btnPickDate.setOnClickListener(x -> {
            int y = cal.get(Calendar.YEAR);
            int m = cal.get(Calendar.MONTH);
            int d = cal.get(Calendar.DAY_OF_MONTH);
            new DatePickerDialog(requireContext(), (view, year, month, dayOfMonth) -> {
                cal.set(Calendar.YEAR, year);
                cal.set(Calendar.MONTH, month);
                cal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                etDate.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.getTime()));
            }, y, m, d).show();
        });

        // اختيار الوقت
        btnPickTime.setOnClickListener(x -> {
            int hh = cal.get(Calendar.HOUR_OF_DAY);
            int mm = cal.get(Calendar.MINUTE);
            new TimePickerDialog(requireContext(), (view, hourOfDay, minute) -> {
                cal.set(Calendar.HOUR_OF_DAY, hourOfDay);
                cal.set(Calendar.MINUTE, minute);
                etTime.setText(String.format(Locale.US, "%02d:%02d", hourOfDay, minute));
            }, hh, mm, true).show();
        });

        // تأكيد الحجز
        btnConfirm.setOnClickListener(x -> submitBooking());
    }

    private void submitBooking() {
        // تحقق بسيط من المدخلات
        String specialistStr   = etSpecialistId.getText().toString().trim();
        String organizationStr = etOrganizationId.getText().toString().trim(); // قد يكون فارغًا
        String dateStr         = etDate.getText().toString().trim();
        String timeStr         = etTime.getText().toString().trim();
        String notesStr        = etNotes.getText().toString().trim();

        if (TextUtils.isEmpty(specialistStr)) {
            toast("اختر الأخصائي");
            return;
        }
        if (TextUtils.isEmpty(dateStr) || TextUtils.isEmpty(timeStr)) {
            toast("اختر التاريخ والوقت");
            return;
        }

        // scheduled_at بصيغة متوافقة مع Laravel
        String scheduledAt = dateStr + " " + timeStr + ":00"; // yyyy-MM-dd HH:mm:ss

        Map<String, Object> body = new HashMap<>();
        body.put("specialist_id", Integer.parseInt(specialistStr));
        if (!TextUtils.isEmpty(organizationStr)) {
            body.put("organization_id", Integer.parseInt(organizationStr));
        }
        body.put("type", "individual"); // غيّرها إن لزم: individual|group|organization
        body.put("scheduled_at", scheduledAt);
        if (!TextUtils.isEmpty(notesStr)) body.put("notes", notesStr);

        setLoading(true);
        api.create(body).enqueue(new Callback<Map<String, Object>>() {
            @Override
            public void onResponse(@NonNull Call<Map<String, Object>> call,
                                   @NonNull Response<Map<String, Object>> response) {
                setLoading(false);
                if (!response.isSuccessful()) {
                    toast("فشل الحجز (" + response.code() + ")");
                    return;
                }
                toast("تم حجز الجلسة بنجاح");
                // رجوع لشاشة الجلسات أو إغلاق النافذة
                NavHostFragment.findNavController(BookSessionFragment.this).popBackStack();
            }

            @Override
            public void onFailure(@NonNull Call<Map<String, Object>> call, @NonNull Throwable t) {
                setLoading(false);
                toast("خطأ في الاتصال: " + t.getMessage());
            }
        });
    }

    private void setLoading(boolean v) {
        if (progress != null) progress.setVisibility(v ? View.VISIBLE : View.GONE);
    }

    private void toast(String m) {
        Toast.makeText(requireContext(), m, Toast.LENGTH_SHORT).show();
    }
}