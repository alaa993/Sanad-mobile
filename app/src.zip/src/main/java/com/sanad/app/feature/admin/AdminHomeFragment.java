
package com.sanad.app.feature.admin;
import android.os.Bundle; import android.view.*; import android.widget.TextView; import android.widget.Button;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider;
import com.sanad.app.R;
public class AdminHomeFragment extends Fragment {
  private AdminViewModels.HomeVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_admin_home, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    TextView u=v.findViewById(R.id.tvUsers), sp=v.findViewById(R.id.tvSpecs), org=v.findViewById(R.id.tvOrgs), ap=v.findViewById(R.id.tvApps), apt=v.findViewById(R.id.tvAppsToday), po=v.findViewById(R.id.tvPosts);
    Button btnSpecs=v.findViewById(R.id.btnSpecs), btnOrgs=v.findViewById(R.id.btnOrgs);
    vm=new ViewModelProvider(this).get(AdminViewModels.HomeVM.class);
    vm.state.observe(getViewLifecycleOwner(), d->{ if(d!=null&&d.counters!=null){ u.setText(String.valueOf(d.counters.users)); sp.setText(String.valueOf(d.counters.specialists)); org.setText(String.valueOf(d.counters.organizations)); ap.setText(String.valueOf(d.counters.appointments)); apt.setText(String.valueOf(d.counters.appointments_today)); po.setText(String.valueOf(d.counters.posts)); } });
    btnSpecs.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.adminSpecialistsFragment));
    btnOrgs.setOnClickListener(x-> androidx.navigation.fragment.NavHostFragment.findNavController(this).navigate(R.id.adminOrganizationsFragment));
    vm.load();
  }
}
