package com.sanad.app.data.auth;

import android.content.Context;
import androidx.annotation.Nullable;
import com.sanad.app.models.LoginRequest;
import com.sanad.app.models.LoginResponse;
import com.sanad.app.models.User;
import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Call;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;
import retrofit2.Response;

public class AuthRepository {

    private final AuthApi api;
    private final TokenStore tokens;

    public AuthRepository(Context ctx, String baseUrl) {
        this.tokens = new TokenStore(ctx);

        HttpLoggingInterceptor logging = new HttpLoggingInterceptor();
        logging.setLevel(HttpLoggingInterceptor.Level.BODY);

        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(new AuthInterceptor(ctx))
                .addInterceptor(logging) // remove in prod if undesired
                .build();

        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(baseUrl)
                .client(client)
                .addConverterFactory(GsonConverterFactory.create())
                .build();

        this.api = retrofit.create(AuthApi.class);
    }

    public @Nullable String login(String username, String password) throws Exception {
        LoginRequest body = new LoginRequest(username, password);
        Response<LoginResponse> r = api.login(body).execute();
        if (r.isSuccessful() && r.body() != null && r.body().token != null) {
            tokens.saveToken(r.body().token);
            return r.body().token;
        }
        throw new Exception("Login failed: " + (r.errorBody() != null ? r.errorBody().string() : r.code()));
    }

    public @Nullable User me() throws Exception {
        Response<User> r = api.me().execute();
        if (r.isSuccessful()) { return r.body(); }
        throw new Exception("Me failed: " + r.code());
    }

    public void logout() throws Exception {
        try { api.logout().execute(); } finally { tokens.clear(); }
    }

    public boolean hasToken() { return tokens.hasToken(); }
}
