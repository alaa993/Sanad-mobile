package com.sanad.app.feature.sessions;
import android.content.Context;
import androidx.annotation.NonNull;
import com.sanad.app.data.AppConfig;
import com.sanad.app.data.auth.AuthInterceptor;
import okhttp3.OkHttpClient;
import retrofit2.*;
import retrofit2.converter.gson.GsonConverterFactory;

public class DirectoryRepository {
    private final DirectoryApi api;
    public DirectoryRepository(Context ctx){
        Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(AppConfig.BASE_URL)
            .client(new OkHttpClient.Builder().addInterceptor(new AuthInterceptor(ctx)).build())
            .addConverterFactory(GsonConverterFactory.create())
            .build();
        api = retrofit.create(DirectoryApi.class);
    }
    public interface Listener { void onSuccess(DirectoryModels.Paged d); void onError(Throwable t); }
    public void load(boolean specialists, String search, Integer page, Listener l){
        Callback<DirectoryModels.Paged> cb = new Callback<DirectoryModels.Paged>(){
            @Override public void onResponse(@NonNull Call<DirectoryModels.Paged> c, @NonNull Response<DirectoryModels.Paged> r){
                if(!r.isSuccessful()||r.body()==null){ l.onError(new RuntimeException("bad_response")); return; } l.onSuccess(r.body());
            }
            @Override public void onFailure(@NonNull Call<DirectoryModels.Paged> c, @NonNull Throwable t){ l.onError(t); }
        };
        if (specialists) api.specialists(search, page).enqueue(cb); else api.organizations(search, page).enqueue(cb);
    }
}
