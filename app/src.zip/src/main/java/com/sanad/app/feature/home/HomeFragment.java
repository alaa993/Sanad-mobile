package com.sanad.app.feature.home;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.*;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R;
import com.sanad.app.data.DashboardResponse;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;

import com.sanad.app.feature.library.LibraryFragment;


public class HomeFragment extends Fragment {
    private HomeViewModel vm;
    private View progress, error, content;
    private TextView tvRole, tvUpcoming, tvUnread, tvPoints;
    private ShortcutsAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater i, @Nullable ViewGroup c, @Nullable Bundle s) {
        return i.inflate(R.layout.fragment_home_dashboard, c, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        progress = v.findViewById(R.id.progress);
        error    = v.findViewById(R.id.errorContainer);
        content  = v.findViewById(R.id.content);
        tvRole   = v.findViewById(R.id.tvRole);
        tvUpcoming = v.findViewById(R.id.tvUpcoming);
        tvUnread   = v.findViewById(R.id.tvUnread);
        tvPoints   = v.findViewById(R.id.tvPoints);

//        RecyclerView rv = v.findViewById(R.id.rvShortcuts);
//        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
//        adapter = new ShortcutsAdapter();
//        rv.setAdapter(adapter);
//        adapter.setOnClick(this::navigate);

        v.findViewById(R.id.btnRetry).setOnClickListener(x -> vm.load());

        vm = new ViewModelProvider(this).get(HomeViewModel.class);
        vm.getState().observe(getViewLifecycleOwner(), this::render);
        vm.load();
    }

    private void render(UIState s) {
        if (s==null || s.loading) { show(progress); return; }
        if (s.error!=null)        { show(error);   return; }
        show(content);
        tvRole.setText(arRole(s.role));
        tvUpcoming.setText(String.valueOf(s.upcoming));
        tvUnread.setText(String.valueOf(s.unread));
        tvPoints.setText(String.valueOf(s.points));
//        adapter.submit(s.shortcuts);
    }

    private void show(View t){
        progress.setVisibility(t==progress?View.VISIBLE:View.GONE);
        error.setVisibility(t==error?View.VISIBLE:View.GONE);
        content.setVisibility(t==content?View.VISIBLE:View.GONE);
    }

    private String arRole(String role){
        if ("admin".equals(role)) return "الإدمن";
        if ("organization".equals(role)) return "المؤسسة";
        if ("specialist".equals(role)) return "الأخصائي";
        return "المريض";
    }

    // ✅ تنقّل جاهز


    private void navigate(DashboardResponse.Shortcut s) {
        NavController navController = Navigation.findNavController(requireView());

        switch (s.id) {
            case "sessions":
                navController.navigate(R.id.sessionsFragment);
                break;
            case "chat":
                navController.navigate(R.id.libraryFragment);
                break;
            case "library":
                navController.navigate(R.id.libraryFragment);
                break;
            default:
                Toast.makeText(requireContext(), "الاختصار غير مدعوم بعد", Toast.LENGTH_SHORT).show();
        }
    }
}