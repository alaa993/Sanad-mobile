package com.sanad.app.feature.chat;
import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.*;
public class ChatViewModel extends AndroidViewModel {
    private final ChatRepository repo;
    private final MutableLiveData<java.util.List<ChatModels.Chat>> chats = new MutableLiveData<>(new java.util.ArrayList<>());
    private final MutableLiveData<java.util.List<ChatModels.Message>> messages = new MutableLiveData<>(new java.util.ArrayList<>());
    private int activeChatId = -1; private String lastSince = null;
    public ChatViewModel(@NonNull Application app){ super(app); repo = new ChatRepository(app); }
    public LiveData<java.util.List<ChatModels.Chat>> getChats(){ return chats; }
    public LiveData<java.util.List<ChatModels.Message>> getMessages(){ return messages; }
    public void loadChats(){ repo.list(new ChatRepository.ListCb(){ @Override public void ok(java.util.List<ChatModels.Chat> list){ chats.postValue(list); } @Override public void err(Throwable t){} }); }
    public void openChat(int chatId){ activeChatId = chatId; lastSince = null; fetchNew(); }
    public void fetchNew(){ if(activeChatId<=0) return; repo.messages(activeChatId, lastSince, new ChatRepository.MsgCb(){
        @Override public void ok(java.util.List<ChatModels.Message> msgs){
            if(msgs!=null && !msgs.isEmpty()){
                java.util.List<ChatModels.Message> curr = messages.getValue(); if(curr==null) curr=new java.util.ArrayList<>();
                curr.addAll(msgs); messages.postValue(curr); lastSince = msgs.get(msgs.size()-1).created_at;
            }
        }
        @Override public void err(Throwable t){} }); }
    public void send(String text){ if(activeChatId<=0) return; repo.send(activeChatId, "text", text, new ChatRepository.SendCb(){
        @Override public void ok(ChatModels.Message m){
            java.util.List<ChatModels.Message> curr = messages.getValue(); if(curr==null) curr=new java.util.ArrayList<>();
            curr.add(m); messages.postValue(curr); lastSince = m.created_at;
        }
        @Override public void err(Throwable t){} }); }
}
