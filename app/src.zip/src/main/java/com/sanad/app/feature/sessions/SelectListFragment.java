package com.sanad.app.feature.sessions;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.*;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.annotation.*;
import androidx.fragment.app.Fragment;
import androidx.navigation.NavController;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.sanad.app.R;

public class SelectListFragment extends Fragment {
    public static final String ARG_IS_SPECIALISTS = "isSpecialists";
    public static final String RESULT_ID = "selectedId";
    public static final String RESULT_NAME = "selectedName";

    private DirectoryRepository repo;
    private boolean isSpecialists;
    private RecyclerView rv;
    private ProgressBar progress;
    private EditText etSearch;
    private ListAdapter adapter;

    @Nullable @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_select_list, container, false);
    }

    @Override public void onViewCreated(@NonNull View v, @Nullable Bundle s) {
        super.onViewCreated(v, s);
        isSpecialists = getArguments()!=null && getArguments().getBoolean(ARG_IS_SPECIALISTS, true);
        repo = new DirectoryRepository(requireContext());

        rv = v.findViewById(R.id.recycler);
        progress = v.findViewById(R.id.progress);
        etSearch = v.findViewById(R.id.etSearch);
        adapter = new ListAdapter(item -> {
            Bundle res = new Bundle();
            res.putInt(RESULT_ID, item.id);
            res.putString(RESULT_NAME, item.name);
            getParentFragmentManager().setFragmentResult("picker", res);
            NavController nav = NavHostFragment.findNavController(this);
            nav.popBackStack();
        });
        rv.setLayoutManager(new LinearLayoutManager(requireContext()));
        rv.setAdapter(adapter);

        etSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { load(s.toString()); }
        });

        load(null);
    }

    private void load(String search){
        progress.setVisibility(View.VISIBLE);
        repo.load(isSpecialists, search, 1, new DirectoryRepository.Listener() {
            @Override public void onSuccess(DirectoryModels.Paged d){
                progress.setVisibility(View.GONE);
                adapter.submit(d!=null?d.data:null);
            }
            @Override public void onError(Throwable t){
                progress.setVisibility(View.GONE);
            }
        });
    }

    static class ListAdapter extends RecyclerView.Adapter<ListAdapter.VH> {
        interface Click { void onClick(DirectoryModels.Item it); }
        private java.util.List<DirectoryModels.Item> data = new java.util.ArrayList<>();
        private final Click click;
        ListAdapter(Click c){ click=c; }
        void submit(java.util.List<DirectoryModels.Item> list){ data = list!=null?list:new java.util.ArrayList<>(); notifyDataSetChanged(); }
        @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p, int v){
            return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_select, p, false));
        }
        @Override public void onBindViewHolder(@NonNull VH h, int i){
            DirectoryModels.Item it = data.get(i);
            h.title.setText(it.name);
            h.itemView.setOnClickListener(v -> click.onClick(it));
        }
        @Override public int getItemCount(){ return data.size(); }
        static class VH extends RecyclerView.ViewHolder {
            TextView title;
            VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); }
        }
    }
}
