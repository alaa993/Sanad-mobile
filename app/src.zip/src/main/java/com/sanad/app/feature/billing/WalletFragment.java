
package com.sanad.app.feature.billing;
import android.os.Bundle; import android.view.*; import android.widget.*; import androidx.annotation.*; import androidx.fragment.app.Fragment;
import com.sanad.app.R;
public class WalletFragment extends Fragment {
  private BillingRepository repo; private TextView tvBalance, tvPoints;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_wallet, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    tvBalance=v.findViewById(R.id.tvBalance); tvPoints=v.findViewById(R.id.tvPoints);
    repo=new BillingRepository(requireContext());
    repo.wallet(new BillingRepository.Cb<BillingApi.WalletResponse>(){
      public void ok(BillingApi.WalletResponse d){ tvBalance.setText(String.valueOf(d.balance)); tvPoints.setText(String.valueOf(d.points)); }
      public void err(Throwable e){}
    });
    v.findViewById(R.id.btnTopup100).setOnClickListener(x -> repo.createIntent(100, new BillingRepository.Cb<BillingApi.IntentResponse>(){
      public void ok(BillingApi.IntentResponse d){ Toast.makeText(getContext(), "Intent created", Toast.LENGTH_SHORT).show(); }
      public void err(Throwable e){ Toast.makeText(getContext(), "Error", Toast.LENGTH_SHORT).show(); }
    }));
  }
}
