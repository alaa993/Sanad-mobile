
package com.sanad.app.feature.admin;
import android.os.Bundle; import android.view.*; import android.widget.*;
import androidx.annotation.*; import androidx.fragment.app.Fragment; import androidx.lifecycle.ViewModelProvider; import androidx.recyclerview.widget.*;
import com.sanad.app.R;
import java.util.*;
public class AdminSpecialistsFragment extends Fragment {
  private AdminViewModels.SpecListVM vm;
  @Nullable @Override public View onCreateView(@NonNull LayoutInflater i,@Nullable ViewGroup c,@Nullable Bundle s){ return i.inflate(R.layout.fragment_admin_specialists, c, false); }
  @Override public void onViewCreated(@NonNull View v,@Nullable Bundle s){
    super.onViewCreated(v,s);
    RecyclerView rv=v.findViewById(R.id.rv); rv.setLayoutManager(new LinearLayoutManager(requireContext()));
    SpecAdapter ad=new SpecAdapter(new SpecAdapter.Listener(){
      @Override public void onApprove(int id){ vm.approve(id); }
      @Override public void onReject (int id){ vm.reject(id); }
    }); rv.setAdapter(ad);
    vm=new ViewModelProvider(this).get(AdminViewModels.SpecListVM.class);
    vm.list.observe(getViewLifecycleOwner(), ad::submit);
    v.findViewById(R.id.btnRefresh).setOnClickListener(x-> vm.load());
    vm.load();
  }
  static class SpecAdapter extends RecyclerView.Adapter<SpecAdapter.VH> {
    interface Listener{ void onApprove(int id); void onReject(int id); }
    private final List<AdminModels.Specialists.Specialist> data=new ArrayList<>(); private final Listener ls;
    SpecAdapter(Listener l){ this.ls=l; }
    void submit(List<AdminModels.Specialists.Specialist> d){ data.clear(); if(d!=null) data.addAll(d); notifyDataSetChanged(); }
    @NonNull @Override public VH onCreateViewHolder(@NonNull ViewGroup p,int v){ return new VH(LayoutInflater.from(p.getContext()).inflate(R.layout.item_admin_specialist,p,false)); }
    @Override public void onBindViewHolder(@NonNull VH h,int i){
      AdminModels.Specialists.Specialist s=data.get(i);
      h.title.setText(s.name+" · "+(s.specialty!=null?s.specialty:"-"));
      h.meta.setText("status: "+(s.status!=null?s.status:"-"));
      h.btnApprove.setOnClickListener(x-> ls.onApprove(s.id));
      h.btnReject .setOnClickListener(x-> ls.onReject (s.id));
    }
    @Override public int getItemCount(){ return data.size(); }
    static class VH extends RecyclerView.ViewHolder{
      TextView title, meta; Button btnApprove, btnReject;
      VH(@NonNull View v){ super(v); title=v.findViewById(R.id.tvTitle); meta=v.findViewById(R.id.tvMeta); btnApprove=v.findViewById(R.id.btnApprove); btnReject=v.findViewById(R.id.btnReject); }
    }
  }
}
