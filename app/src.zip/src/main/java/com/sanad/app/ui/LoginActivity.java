package com.sanad.app.ui;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.android.material.button.MaterialButton;
import com.sanad.app.R;
import com.sanad.app.data.AppConfig;
import com.sanad.app.data.auth.AuthRepository;
import com.sanad.app.data.auth.TokenStore;

public class LoginActivity extends AppCompatActivity {

    private EditText usernameInput, passwordInput;
    private MaterialButton btnLogin;
    private AuthRepository authRepository;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        // 🧩 تهيئة الحقول والأزرار
        usernameInput = findViewById(R.id.username);
        passwordInput = findViewById(R.id.password);
        btnLogin = findViewById(R.id.btnLogin);

        // 🧠 تهيئة الريبو الخاص بالمصادقة
        authRepository = new AuthRepository(this, AppConfig.BASE_URL);

        btnLogin.setOnClickListener(view -> {
            String username = usernameInput.getText().toString().trim();
            String password = passwordInput.getText().toString().trim();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "الرجاء إدخال اسم المستخدم وكلمة المرور", Toast.LENGTH_SHORT).show();
                return;
            }

            // ⏳ عملية تسجيل الدخول
            new Thread(() -> {
                try {
                    String token = authRepository.login(username, password);
                    if (token != null) {
                        // ✅ تم تسجيل الدخول بنجاح، خزّن التوكن
                        new TokenStore(this).saveToken(token);

                        runOnUiThread(() -> {
                            Toast.makeText(this, "تم تسجيل الدخول بنجاح", Toast.LENGTH_SHORT).show();
                            startActivity(new Intent(this, MainActivity.class));
                            finish();
                        });
                    } else {
                        runOnUiThread(() ->
                                Toast.makeText(this, "فشل تسجيل الدخول", Toast.LENGTH_SHORT).show()
                        );
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                    runOnUiThread(() ->
                            Toast.makeText(this, "حدث خطأ في الاتصال بالخادم", Toast.LENGTH_SHORT).show()
                    );
                }
            }).start();
        });
    }
}